/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rudy Duarte
 */

/** Class to interact with database. SQLite commands are here
 * 
 */




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class SQLiteJDBC
{
    public static void main(String args[])
    { 
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Rudy Duarte\\Documents\\College\\Senior Year (2013-2014)\\CSC 271\\Final DBMS Project: Girl_Scouts_DB");
           
        }
        catch (Exception e){
            System.err.println( e.getClass().getName() + ":" + e.getMessage());
            System.exit(0);
            
        }
System.out.println("Database opened successfully!");
            }
}

