/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rudy Duarte
 */

/** Class to interact with database. 
 * 
 */




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;



public class SQLiteJDBC
{
    //private String driverName = "org.sqlite.JDBC";
    private Connection conn;
    private Statement stmt;
    
    public SQLiteJDBC() throws Exception {
//      conn = null; 
//      try {
            Class.forName("org.sqlite.JDBC");
//            conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Rudy Duarte\\Documents\\College\\Senior Year (2013-2014)\\CSC 271\\Final DBMS Project: Girl_Scouts_DB");
           
//        }
//        catch (Exception e){
//            System.err.println( e.getClass().getName() + ":" + e.getMessage());
//            System.exit(0);
//            
//        }
//      System.out.println("Database is Connected");
    }
    
    public void openConnection() throws Exception {
       conn = DriverManager.getConnection("jdbc:sqlite:/users/longpham/Dropbox/test.db");
       stmt = conn.createStatement();
   }

   public void closeConnection() throws Exception {
       stmt.close();
       conn.close();
   }
   
   public void insertScout(String name, int age) throws Exception{
       this.openConnection();
       stmt.executeUpdate("insert into scout(scout_name, age) values('" + name + "'," + age + ");");
       this.closeConnection();
   }
   
   public void insertOrder(String cust_name, String address, int phone, String email) throws Exception{
       this.openConnection();
       stmt.executeUpdate("insert into customer values (null, '" + cust_name + "','" + address + "'," + phone + ",'" + email + "');");
       this.closeConnection();
   }
   
   
   
            }


